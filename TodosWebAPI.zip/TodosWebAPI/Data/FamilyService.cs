﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Models;
using TodosWebAPI.Data;
using TodosWebAPI.Models;

namespace AdvancedTodoWebAPI.Data {
    
public class FamilyService : IFam
{
    private string uri = "https://localhost:5001";
    //private string uri = "https://jsonplaceholder.typicode.com/";
    //private string famFile = "families.json";
    private IList<Family> fams;
    private readonly HttpClient client;
    private int x;

    public FamilyService()
    {
        client = new HttpClient();
    }

    /*public FamilyService() {
        if (!File.Exists(famFile)) {
            WriteFamsToFile();
        } else {
            string content = File.ReadAllText(famFile);
            fams = JsonSerializer.Deserialize<List<Family>>(content);
        }
    }
    private void WriteFamsToFile() {
        string productsAsJson = JsonSerializer.Serialize(fams);
        
        File.WriteAllText(famFile, productsAsJson);
    }*/
    
    //getfam virker ikke helt 
    public async Task<IList<Family>> GetFamAsync()
    {
        HttpResponseMessage reponse = await client.GetAsync(uri + "Family");
        if (!reponse.IsSuccessStatusCode)
        {
            throw new Exception("Error or whatever");
        }

        string message = await reponse.Content.ReadAsStringAsync();
        List<Family> result = JsonSerializer.Deserialize<List<Family>>(message);
        return result;
    }
    
    
    //remove fam virker ikke helt 
    public async Task RemoveFamAsync(string famId, int intt)
    {
        HttpResponseMessage response = await client.DeleteAsync($"{uri}/{famId}");
        if (!response.IsSuccessStatusCode)
        {
            throw new Exception($"Error, {response.StatusCode}, {response.ReasonPhrase}");
        }
    }

    
    //add family virker nu 
    public async Task AddFamAsync(Family fam)
    {
        string todoAsJson = JsonSerializer.Serialize(fam);
        HttpContent content = new StringContent(todoAsJson,
            Encoding.UTF8,
            "application/json");
        HttpResponseMessage response = await client.PostAsync(uri + "Fam", content);
        if (!response.IsSuccessStatusCode)
        {
            throw new Exception($"Error, {response.StatusCode}, {response.ReasonPhrase}");
        }
    }
    
    public Task<Family> UpdateFamAsync(Family fam)
    {
        throw new NotImplementedException();
    }
}
}