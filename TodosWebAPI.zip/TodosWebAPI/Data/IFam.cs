﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Models;
using TodosWebAPI.Models;

namespace TodosWebAPI.Data
{
    public interface IFam
    {
        Task<IList<Family>> GetFamAsync();
        Task   AddFamAsync(Family fam);
        Task   RemoveFamAsync(string famId, int housenumber);
        Task<Family>   UpdateFamAsync(Family fam);
    }
    }
