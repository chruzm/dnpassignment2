﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Models;
using TodosWebAPI.Models;

namespace TodosWebAPI.Data
{
    public class FamService : IFam
    {
        private string todoFile = "families.json";
        private IList<Family> fams;
        
        public FamService() {
            if (!File.Exists(todoFile)) {
                //Seed();
                WriteTodosToFile();
            } else {
                string content = File.ReadAllText(todoFile);
                fams = JsonSerializer.Deserialize<List<Family>>(content);
            }
        }
        private void WriteTodosToFile() {
            string productsAsJson = JsonSerializer.Serialize(fams);
        
            File.WriteAllText(todoFile, productsAsJson);
        }
        
        public async Task<IList<Family>> GetFamAsync() {
            List<Family> tmp = new List<Family>(fams);
            return tmp;
        }
        
        public async Task AddFamAsync(Family fam) {
            //int max = fams.Max(famo => fam.TodoId);
            //fam. = (++max);
            fams.Add(fam);
            WriteTodosToFile();
            //return fam;
        }

        public async Task RemoveFamAsync(string famId, int housenr) {
            Family toRemove = fams.First(t => t.StreetName == famId && t.HouseNumber == housenr);
            fams.Remove(toRemove);
            WriteTodosToFile();
        }
        

        public async Task<Family> UpdateFamAsync(Family fam) {
            Family toUpdate = fams.FirstOrDefault(t => t.StreetName == fam.StreetName && t.HouseNumber == fam.HouseNumber);
            if(toUpdate == null) throw new Exception($"Did not find family with id: {fam.StreetName} or house number{fam.HouseNumber}");
            //toUpdate.IsCompleted = todo.IsCompleted;
            WriteTodosToFile();
            return toUpdate;
        }
    }
}