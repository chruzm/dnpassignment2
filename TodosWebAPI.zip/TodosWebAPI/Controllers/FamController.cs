﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Models;
using TodosWebAPI.Data;

namespace TodosWebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FamController : ControllerBase
    {
        private int x;
        private int y;
        private IFam ifam; 
        public FamController(IFam ifam)
        {
            this.ifam = ifam;
        }
        
        [HttpGet]
        public async Task<ActionResult<IList<Family>>>
            GetFamAsync([FromQuery] int? housenumber, [FromQuery] string? lastname)
        {
            try
            {
                IList<Family> famluh = await ifam.GetFamAsync();
                if (housenumber != null)
                {
                    famluh = famluh.Where(todo => famluh[x].HouseNumber == housenumber).ToList();
                }

                if (lastname != null)
                {
                    famluh = famluh.Where(todo => famluh[x].Adults[y].LastName == lastname).ToList();
                }

                return Ok(famluh);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return StatusCode(500, e.Message);
            }
        }
        
        [HttpDelete]
        [Route("delete via id and adult Id")]
        public async Task<ActionResult> DeleteFamAsync([FromRoute] string id, int number)
        {
            try
            {
                await ifam.RemoveFamAsync(id, number);
                return Ok();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return StatusCode(500, e.Message);
            }
        }
        
        [HttpPost]
        public async Task<ActionResult<Family>> AddFamAsync([FromBody] Family faam)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                await ifam.AddFamAsync(faam);
                return Ok();
                //return Created($"/{added.Adults[x].LastName}", added); // return newly added to-do, to get the auto generated id
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return StatusCode(500, e.Message);
            }
        }
    }
}