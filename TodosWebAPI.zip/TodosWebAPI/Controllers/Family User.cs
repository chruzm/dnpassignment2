﻿using Microsoft.AspNetCore.Mvc;

namespace TodosWebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class Family_User
    {
        
    }
}