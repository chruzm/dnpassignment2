﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Text.Json.Serialization;

namespace TodosWebAPI.Models
{
    public class Todo
    {
        [Required]
        [NotNull, Range(1, int.MaxValue, ErrorMessage = "Enter number > 1")]
        [JsonPropertyName("userId")]
        public int UserId { get; set; }
        
        [JsonPropertyName("id")]
        public int TodoId { get; set; }
        [Required, MaxLength(128)]
        
        [JsonPropertyName("title")]
        public string Title { get; set; }
        
        [JsonPropertyName("completed")]
        public bool IsCompleted { get; set; }
        
    }
}