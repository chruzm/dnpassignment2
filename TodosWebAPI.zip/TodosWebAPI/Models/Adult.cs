namespace Models {
public class Adult : Person {
    public Job JobTitle { get; set; }
    public string LastName { get; set; }
    public string FirstName { get; set; }
}
}