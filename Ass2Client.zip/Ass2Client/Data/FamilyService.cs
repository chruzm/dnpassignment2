﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Models;
using Ass2Client.Data;



namespace AdvancedTodoWebAPI.Data {
    
public class FamilyService : IFam.IFam
{
    private string uri = "https://localhost:5001";
    /*private string uri = "https://jsonplaceholder.typicode.com/";
    /private string famFile = "families.json";
    private readonly HttpClient client;
    private int x;*/

    public FamilyService()
    {
        client = new HttpClient();
    }
    HttpClient client = new HttpClient();
    
     
    public async Task<IList<Family>> GetFamAsync()
    {
        using HttpClient client = new HttpClient();
        HttpResponseMessage responseMessage = await client.GetAsync("https://localhost:5001/Fam");
        if (!responseMessage.IsSuccessStatusCode)
            throw new Exception(@"Error: {responseMessage.StatusCode}, {responseMessage.ReasonPhrase}");
        
        string result = await responseMessage.Content.ReadAsStringAsync();
        List<Family> fams = JsonSerializer.Deserialize<List<Family>>(result, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        });
        return fams;
        
    }

    public Task AddFamAsync(Family fam)
    {
        throw new NotImplementedException();
    }


    //remove fam virker ikke helt 
    public async Task RemoveFamAsync(int famId)
    {
        using HttpClient client = new HttpClient();
        HttpResponseMessage response = await client.DeleteAsync("https://localhost:5001");
        if(!response.IsSuccessStatusCode)
            throw new Exception(@"Error: {responseMessage.StatusCode}, {responseMessage.ReasonPhrase}");
    }

    private string x;
    //add family virker nu 
    public async Task<string> Add(Family fam)
    {
        HttpClient client = new HttpClient();
        Family todo = new Family {
            StreetName = "",
            HouseNumber = 0,
        };
        string todoSerialized = JsonSerializer.Serialize(todo);

        StringContent content = new StringContent(
            todoSerialized,
            Encoding.UTF8,
            "application/json"
        );

        HttpResponseMessage response = await client.PostAsync("https://jsonplaceholder.typicode.com/Fam", content);
        return response.ToString();
    }
    
    public Task<Family> UpdateFamAsync(Family fam)
    {
        throw new NotImplementedException();
    }
}
}