﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Models;


namespace IFam
{
    public interface IFam
    {
        Task<IList<Family>> GetFamAsync();
        Task   AddFamAsync(Family fam);
        Task   RemoveFamAsync(int todoId);
        Task<Family>   UpdateFamAsync(Family fam);
    }
    }
