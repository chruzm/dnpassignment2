﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Ass2Client.Data;
using Ass2Client.Models;
using Models;

namespace LoginExample.Data.Impl {
    public class NormalIUSERVICE : IUService {
        private List<User> users;

        public NormalIUSERVICE() {
            users = new[] {
                new User {
                    Username = "bob",
                    Password = "123",
                    SecurityLevel = 1,
                },
                new User {
                    Username = "bobby",
                    Password = "12",
                    SecurityLevel = 2,
                }
            }.ToList();
        }


        public User ValidateUser(string userName, string password) {
            User first = users.FirstOrDefault(user => user.Username.Equals(userName));
            if (first == null) {
                throw new Exception("User not found");
            }

            if (!first.Password.Equals(password)) {
                throw new Exception("Incorrect password");
            }
            return first;
        }
    }
}