﻿using System.Threading.Tasks;
using Ass2Client.Models;

namespace Ass2Client.Data
{
    public interface IUService
    {
        //ændre til task for webservice
        User ValidateUser(string userName, string passWord);
    }
}