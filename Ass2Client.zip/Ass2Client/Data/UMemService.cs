﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Ass2Client.Models;

namespace Ass2Client.Data
{
    public class UMemService : IUService
    {
        private string uri = "https://localhost:5001";
        private ICollection<User> users;
        
        public async Task<User> ValidateUser(string userName, string passWord)
        {
            using HttpClient client = new HttpClient();
            HttpResponseMessage responseMessage = await client.GetAsync("https://localhost:5001/Users");
            if (!responseMessage.IsSuccessStatusCode)
                throw new Exception(@"Error: {responseMessage.StatusCode}, {responseMessage.ReasonPhrase}");
            string result = await responseMessage.Content.ReadAsStringAsync();
            {
                User user = users.FirstOrDefault(u => u.Username.Equals(userName) && u.Password.Equals(passWord));
                if (user != null)
                {
                    return user;
                } 
                throw new Exception("User not found");
            }
        }
    }
}*/