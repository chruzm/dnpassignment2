﻿namespace Ass2Client.Models {
    public class User {
        public string Username { get; set; }
        public string Password { get; set; }
        public int SecurityLevel { get; set; }
        //public string sec { get; set; }
    }
}